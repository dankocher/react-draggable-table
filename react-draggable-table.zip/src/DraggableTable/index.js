import DraggableTable from "./DraggableTable";

export default DraggableTable;