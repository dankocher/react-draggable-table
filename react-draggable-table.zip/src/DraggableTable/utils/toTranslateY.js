const toTranslateY = (value) => {
    return `translateY(${value}px)`;
};
export default toTranslateY;